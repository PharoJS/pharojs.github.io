# PharoJS
PharoJS: Develop in Pharo, Run on Javascript

- Pharo code available on repo: http://smalltalkhub.com/#!/~noury/PharoJS
- Doc available at: http://pharojs.org/
