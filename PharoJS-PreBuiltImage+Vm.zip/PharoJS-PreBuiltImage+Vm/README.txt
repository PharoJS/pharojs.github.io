Pharo 5.0

This distribution was built January 23, 2017.